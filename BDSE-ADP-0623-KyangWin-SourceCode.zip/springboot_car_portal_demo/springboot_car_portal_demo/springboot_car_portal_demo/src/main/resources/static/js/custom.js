function sayHello()  {    
  alert("Hello from JavaScript");
}